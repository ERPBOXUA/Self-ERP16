{
    'name': 'Self-ERP IAP Client',
    'category': 'Services',
    'version': '17.0.7.10.0',
    'license': 'OPL-1',
    'installable': True,
    'application': False,
    'auto_install': False,

    'author': 'Self-ERP',
    'support': 'apps@self-erp.com',
    'summary': """Self-ERP IAP Client""",

    'images': [
        'static/description/icon.png',
    ],

    'depends': [
        'account',
        'iap',
    ],

    'data': [
        'security/ir.model.access.csv',

        'data/ir_cron_data.xml',

        'views/iap_update_views.xml',
        'views/res_config_settings_views.xml',
        'views/selferp_iap_client_menus.xml',

        'wizard/iap_setup_views.xml',
        'wizard/iap_update_confirm_views.xml',
    ],

    'post_init_hook': 'post_init_hook',
}
