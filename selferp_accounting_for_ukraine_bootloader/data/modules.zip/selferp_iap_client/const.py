PRODUCT_CODE__LOADER = 'loader'
PRODUCT_CODE__DEFAULT = 'ua_acc'

PRODUCTS = (
    PRODUCT_CODE__LOADER,
    PRODUCT_CODE__DEFAULT,
)


PARAM_NAME__SERVER_ENDPOINT = 'selferp.server.endpoint'

PARAM_NAME__INSTANCE_DATABASE_UUID = 'database.uuid'
PARAM_NAME__INSTANCE_NAME = 'iap.instance.name'
PARAM_NAME__INSTANCE_EMAIL = 'iap.instance.email'
PARAM_NAME__INSTANCE_PHONE = 'iap.instance.phone'
PARAM_NAME__INSTANCE_REGISTERED = 'iap.instance.registered'
PARAM_NAME__INSTANCE_UPDATE_LAST_CHECK = 'iap.instance.update.last_check'
PARAM_NAME__INSTANCE_UPDATE_LAST_DATE = 'iap.instance.update.last_date'


MODULES_LOADER = 'selferp_iap_client'
MODULES_PREFIX = 'selferp_'
MODULES_THIRDPARTY = [
    # use this list to add third-party modules names
    # (comma separated strings)
]


URL_BASE = '/selferp/iap'
URL_REGISTER = f'{URL_BASE}/register'
URL_REGISTER_COMPLETE = f'{URL_BASE}/complete_registration'
URL_UPDATE_CHECK = f'{URL_BASE}/update/check'
