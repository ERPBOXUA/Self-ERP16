--
-- Remove Self-ERP IAP params
--
DELETE FROM ir_config_parameter
 WHERE key LIKE 'iap.instance.%';
