from .const import PARAM_NAME__SERVER_ENDPOINT


def post_init_hook(env):
    # setup server endpoint
    env['ir.config_parameter'].set_param(PARAM_NAME__SERVER_ENDPOINT, 'https://www.self-erp.com')
