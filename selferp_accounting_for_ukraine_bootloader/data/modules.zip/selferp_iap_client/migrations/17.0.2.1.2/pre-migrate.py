import logging
import os
import shutil

from odoo.tools import config


_logger = logging.getLogger(__name__)


def migrate(cr, version):
    try:
        apps_path = config.addons_data_dir
        if not os.path.exists(apps_path):
            for module_path in os.listdir(apps_path):
                module_name = os.path.split(module_path)[-1]
                if module_name.startswith('kw_'):
                    shutil.rmtree(module_path)
    except Exception as e:
        _logger.error("Remove KW modules error", exc_info=e)
