def migrate(cr, version):
    cr.execute('''
        UPDATE iap_update
           SET build_id = build_number
         WHERE build_id IS NULL
    ''')
