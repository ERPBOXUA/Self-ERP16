import base64
import io
import logging
import os
import psycopg2
import shutil
import tempfile
import threading
import werkzeug
import zipfile

from odoo import release, api, fields, models, _
from odoo.exceptions import UserError
from odoo.modules.module import adapt_version, load_manifest, check_manifest_dependencies
from odoo.service import server
from odoo.tools import config

from odoo.addons.base.models.ir_module import assert_log_admin_access
from odoo.addons.iap.tools.iap_tools import iap_jsonrpc

from ..const import (
    PRODUCTS,
    PARAM_NAME__SERVER_ENDPOINT,
    PARAM_NAME__INSTANCE_DATABASE_UUID,
    PARAM_NAME__INSTANCE_NAME,
    PARAM_NAME__INSTANCE_EMAIL,
    PARAM_NAME__INSTANCE_PHONE,
    PARAM_NAME__INSTANCE_REGISTERED,
    PARAM_NAME__INSTANCE_UPDATE_LAST_CHECK,
    PARAM_NAME__INSTANCE_UPDATE_LAST_DATE,
    MODULES_LOADER,
    MODULES_PREFIX,
    MODULES_THIRDPARTY,
    URL_REGISTER,
    URL_REGISTER_COMPLETE,
    URL_UPDATE_CHECK,
)


_logger = logging.getLogger(__name__)


class IAPUpdate(models.Model):
    _name = 'iap.update'
    _description = "Self-ERP Update"
    _order = 'product_code, build_number DESC, id DESC'
    _rec_name = 'build_number'

    product_code = fields.Char(
        string="Product Code",
        required=True,
        readonly=True,
        index=True,
        copy=False,
    )

    build_id = fields.Char(
        string="Build ID",
        required=True,
        readonly=True,
        index=True,
        copy=False,
    )
    build_number = fields.Char(
        string="Build Number",
        required=True,
        readonly=True,
        index=True,
        copy=False,
    )

    state = fields.Selection(
        selection=[
            ('available', "Available"),
            ('applied', "Applied"),
            ('skipped', "Skipped"),
        ],
        required=True,
        readonly=True,
        default='available',
        index=True,
        copy=False,
        string="State",
    )

    short_description = fields.Char(
        string="Short Description",
        required=True,
        readonly=True,
        translate=True,
    )
    full_description = fields.Text(
        string="Full Description",
        readonly=True,
        translate=True,
    )
    details_url = fields.Char(
        string="Details URL",
        readonly=True,
    )

    data = fields.Binary(
        string="Data",
        required=True,
        readonly=True,
    )

    @api.model
    def iap_register(self):
        IrConfigParameter = self.env['ir.config_parameter'].sudo()

        # call server
        self._request(
            URL_REGISTER,
            {
                'name': IrConfigParameter.get_param(PARAM_NAME__INSTANCE_NAME),
                'email': IrConfigParameter.get_param(PARAM_NAME__INSTANCE_EMAIL),
                'phone': IrConfigParameter.get_param(PARAM_NAME__INSTANCE_PHONE),
            }
        )

    @api.model
    def iap_complete_registration(self, email_validation_code):
        # call server
        result = self._request(
            URL_REGISTER_COMPLETE,
            {
                'email_validation_code': email_validation_code,
            },
        )

        # remember a validation code as instance key
        # (to be used with each request)
        # only after success complete registration request
        self.env['ir.config_parameter'].sudo().set_param(PARAM_NAME__INSTANCE_REGISTERED, email_validation_code)

        # save result
        self._save_response(result)

        # and apply update
        self.iap_apply_update()

    @api.model
    @assert_log_admin_access
    def iap_check_for_update(self, silent=False):
        # check if it's already registered
        if not self.env['ir.config_parameter'].sudo().get_param(PARAM_NAME__INSTANCE_REGISTERED):
            return

        # call server
        result = self._request(URL_UPDATE_CHECK, silent=silent)

        # only save result
        self._save_response(result)

    @api.model
    @assert_log_admin_access
    def iap_apply_update(self):
        # check any update existing
        if not self.search_count([
            ('product_code', 'in', PRODUCTS),
            ('state', '=', 'available'),
        ]):
            return

        # check state
        if not self.env.registry.ready or self.env.registry._init:
            raise UserError(_("The Self-ERP modules upgrade cannot be called on init or non loaded registries."))

        if getattr(threading.current_thread(), 'testing', False):
            raise RuntimeError("Module operations inside tests are not transactional and thus forbidden.")

        try:
            # This is done because the installation/uninstallation/upgrade can modify a currently
            # running cron job and prevent it from finishing, and since the ir_cron table is locked
            # during execution, the lock won't be released until timeout.
            self.env.cr.execute("SELECT * FROM ir_cron FOR UPDATE NOWAIT")
        except psycopg2.OperationalError:
            raise UserError(_(
                "Odoo is currently processing a scheduled action.\n"
                "Module operations are not possible at this time, "
                "please try again later or contact your system administrator."
            ))

        # WO: replace restart function to prevent autoreload sources
        _restart = server.restart
        server.restart = lambda: None

        try:
            module_names = []

            # unpack result
            now = fields.Datetime.now()
            apps_path = config.addons_data_dir
            # @TODO: maybe get current permissions and return them back finally ?
            if not os.path.exists(apps_path):
                parent_path = apps_path.rpartition(os.sep)[0]
                os.chmod(parent_path, 0o700)
                os.makedirs(apps_path, mode=0o700, exist_ok=True)
            else:
                os.chmod(apps_path, 0o700)

            # for each product
            for product_code in PRODUCTS:
                # check last not applied updates
                # it should always be one or zero
                update = self.search(
                    [
                        ('product_code', '=', product_code),
                        ('state', '=', 'available'),
                    ],
                    order='id DESC',
                    limit=1,
                )

                if update:
                    with tempfile.TemporaryDirectory() as temp_dir:
                        # unpack into temp dir
                        update_data = base64.b64decode(update.data)
                        with zipfile.ZipFile(io.BytesIO(update_data), 'r') as archive:
                            archive.extractall(temp_dir)

                        for module_path in os.listdir(temp_dir):
                            # get module name and remember it for update later
                            module_name = os.path.split(module_path)[-1]
                            module_names.append(module_name)

                            # remove existing dir if exists
                            destination_path = os.path.join(apps_path, module_name)
                            if os.path.exists(destination_path):
                                shutil.rmtree(destination_path)

                            # move new dir
                            shutil.move(os.path.join(temp_dir, module_path), destination_path)

                    # mark update record as applied
                    update.state = 'applied'

            if module_names:
                IrModuleModule = self.env['ir.module.module']

                # update modules list
                IrModuleModule.update_list()

                # mark to update already installed modules
                to_update = IrModuleModule.search([
                    ('name', 'in', module_names),
                    ('state', '=', 'installed'),
                ])
                to_update_filtered = IrModuleModule.browse()

                # if there are already installed modules
                if to_update:
                    # check each module
                    dependencies = []
                    for module in to_update:
                        # get manifest
                        manifest = load_manifest(module.name)

                        # check version changing
                        if module.latest_version == adapt_version(manifest['version']):
                            continue

                        # check external dependencies
                        check_manifest_dependencies(manifest)

                        # add for update
                        to_update_filtered += module

                        # remember dependencies
                        dependencies += manifest.get('depends') or []

                    # mark those modules for update
                    if to_update_filtered:
                        # check dependencies existing
                        dependencies = list(set(dependencies))
                        to_install = IrModuleModule.search([
                            ('name', 'in', dependencies),
                            ('state', '=', 'uninstalled'),
                        ])
                        if to_install:
                            #
                            # @TODO
                            #
                            # This may cause upgrade problems if:
                            #   - new module added;
                            #   - this new module depends on another module which already installed;
                            #   - there are changes in this installed module (will be applied on upgrade)
                            #     which used by new module (in post init hook actually);
                            #   - there is another module(s) already installed which depends on this new module.
                            #
                            # What will happen in this case:
                            #   1) update build will be downloaded and unpacked
                            #      (with old version of modules replacement);
                            #   2) code of new modules not loaded yet;
                            #   3) modules info (list of modules with their versions) updated in database;
                            #   4) we get all modules which not installed yet but but
                            #      required by dependency from another already installed module;
                            #   5) this list of modules contains our new module;
                            #   6) we try to install this modules;
                            #   7) in post init hook of new module we use code (or data) from
                            #      another module which already installed (but not updated yet);
                            #   8) but because of existing module not updated yet the code (or data)
                            #      from it not available yet;
                            #   9) new module installation failed;
                            #   10) upgrade process stopped.
                            #
                            # Detected and described in ticket #628
                            # (https://www.self-erp.com/web#id=628&cids=1&menu_id=147&action=216&active_id=1&model=helpdesk.ticket&view_type=form)
                            # and solved with HOTFIX
                            #
                            to_install.button_immediate_install()

                        # mark modules for update
                        to_update_filtered.write({
                            'state': 'to upgrade',
                        })

                # set the last update date
                self.env['ir.config_parameter'].set_param(
                    PARAM_NAME__INSTANCE_UPDATE_LAST_DATE,
                    fields.Datetime.to_string(now),
                )

                # clear other (available but not applied) updates info
                self.search([('state', '=', 'available')]).write({
                    'state': 'skipped',
                })

                # save all changes manually
                self.env.cr.commit()

            # and just restart Odoo (always)
            # to reload, install or update apps
            _restart()

        finally:
            # setup restart function back
            server.restart = _restart

    @api.model
    def _request(self, path, data=None, ttl=1200, silent=False):
        try:
            # prepare data for request
            params = {
                'instance_data': self._get_instance_data(),
            }
            if data:
                params['data'] = data

            # call server
            IrConfigParameter = self.env['ir.config_parameter'].sudo()
            result = iap_jsonrpc(
                werkzeug.urls.url_join(
                    IrConfigParameter.get_param(PARAM_NAME__SERVER_ENDPOINT),
                    path,
                ),
                params=params,
                timeout=ttl or 1200,
            )
            result = result or {}

            # result data
            message = result.get('message')
            if message:
                if result.get('error'):
                    _logger.error(message)
                    raise UserError(message)
                else:
                    _logger.info(message)

            # return result data
            return result
        except Exception as e:
            if not silent:
                raise e

    @api.model
    def _get_instance_data(self):
        #
        # get user's info
        #
        domain_users = [
            ('id', 'not in', [
                self.env.ref('base.default_user').id,
                self.env.ref('base.user_root').id,
                self.env.ref('base.public_user').id,
            ]),
        ]

        # if you need to get only users of some specified group,
        # "Bookkeeper", for example, then you need to add something like this:
        #
        # user_group_id = self.env['ir.model.data']._xmlid_to_res_id('account.group_account_user')
        # domain_users += [
        #     ('groups_id', 'in', [user_group_id]),
        # ]
        #
        # but for now just get all INTERNAL users info (except root and user's template)
        user_group_id = self.env['ir.model.data']._xmlid_to_res_id('base.group_user')
        domain_users += [
            ('groups_id', 'in', [user_group_id]),
        ]

        users = self.env['res.users'].sudo().with_context(active_test=False).search_read(
            domain=domain_users,
            fields=['id', 'name', 'login', 'active', 'create_date', 'write_date', 'login_date'],
        )

        #
        # get modules
        #
        IrModuleModule = self.env['ir.module.module'].sudo()
        module_loader = IrModuleModule.search_read(
            domain=[('name', '=', MODULES_LOADER)],
            fields=['latest_version'],
            limit=1,
        )[0]
        modules = IrModuleModule.search_read(
            domain=[
                '|',
                    ('name', '=like', f'{MODULES_PREFIX}%'),
                    ('name', 'in', MODULES_THIRDPARTY),
            ],
            fields=['name', 'shortdesc', 'state', 'latest_version', 'installed_version'],
        )

        #
        # get products
        #
        products = []

        def _get_update_info(domain):
            update = self.env['iap.update'].search_read(
                domain=domain,
                fields=['id', 'build_id', 'build_number'],
                order='id DESC',
                limit=1,
            )
            return update and update[0] or {}

        for product_code in PRODUCTS:
            product_info = {
                'code': product_code,
            }

            # get applied update info
            applied = _get_update_info([
                ('product_code', '=', product_code),
                ('state', '=', 'applied'),
            ])

            # get latest available (not applied) update info
            domain_available = [
                ('product_code', '=', product_code),
                ('state', '=', 'available'),
            ]
            if applied:
                product_info['current'] = applied.get('build_id')
                domain_available.append(('id', '>', applied['id']))

            available = _get_update_info(domain_available)
            if available:
                product_info['available'] = available.get('build_id')

            # always add product info even it's empty
            # to notify about used products
            products.append(product_info)

        #
        # prepare and return instance data
        #
        IrConfigParameter = self.env['ir.config_parameter'].sudo()
        return {
            'version': release.version,
            'dbuuid': IrConfigParameter.get_param(PARAM_NAME__INSTANCE_DATABASE_UUID),
            'database_name': self.env.cr.dbname,
            'loader_version': module_loader.get('latest_version'),
            'instance_key': IrConfigParameter.get_param(PARAM_NAME__INSTANCE_REGISTERED),
            'base_url': self.get_base_url(),

            # products info
            'products': products,

            # get users info
            'users': [
                {
                    'client_ref': user.get('id'),
                    'name': user.get('name'),
                    'login': user.get('login'),
                    'state': 'active' if user.get('active') else 'archived',
                    'client_create_date': fields.Datetime.to_string(user.get('create_date')),
                    'client_write_date': fields.Datetime.to_string(user.get('write_date')),
                    'client_login_date': user.get('login_date') and fields.Datetime.to_string(user.get('login_date')) or None,
                }
                for user in users
            ],

            # get modules info
            'modules': [
                {
                    'tech_name': module.get('name'),
                    'name': module.get('shortdesc') or module.get('name'),
                    'state': module.get('state'),
                    'version_installed': module.get('latest_version'),
                    'version_available': module.get('installed_version'),
                }
                for module in modules
            ],
        }

    @api.model
    def _save_response(self, response_data):
        if response_data:
            # save current state info
            self._save_state(response_data.get('state'))

            # save update info (if exists)
            self._save_update(response_data.get('update'))

    @api.model
    def _save_state(self, state_info):
        if not state_info:
            return

        products_current = (state_info.get('products') or {}).get('current') or {}
        if products_current:
            def _update_product_build_number(product_code, build_id, build_number):
                if product_code and build_id and build_number:
                    update = self.search(
                        domain=[
                            ('product_code', '=', product_code),
                            ('build_id', '=', build_id),
                        ],
                        limit=1,
                    )
                    if update and update.build_number != build_number:
                        update.build_number = build_number

            for product_code, product in products_current.items():
                _update_product_build_number(product_code, product.get('build_current_id'), product.get('build_current_number'))
                _update_product_build_number(product_code, product.get('build_available_id'), product.get('build_available_number'))

    @api.model
    def _save_update(self, update_info):
        # remember the last update check date
        self.env['ir.config_parameter'].sudo().set_param(
            PARAM_NAME__INSTANCE_UPDATE_LAST_CHECK,
            fields.Datetime.to_string(fields.Datetime.now()),
        )

        # save updates
        if update_info:
            # check update for each product
            for product_code in PRODUCTS:
                product_update = update_info.get(product_code)
                if not product_update:
                    continue

                # try to find update
                build_number = product_update.get('build_number')
                build_id = product_update.get('build_id') or build_number
                update = self.search(
                    [
                        ('product_code', '=', product_code),
                        ('build_id', '=', build_id),
                    ],
                    limit=1,
                )

                short_description = product_update.get('short_description')
                full_description = product_update.get('full_description')

                if update:
                    if update.state == 'applied':
                        continue

                    update.write({
                        'details_url': product_update.get('details_url'),
                        'data': product_update.get('data'),
                    })

                else:
                    # mark all 'available' updates as skipped, because only one
                    # update can be available in the same time
                    self.with_context(active_test=False).search([
                        ('product_code', '=', product_code),
                        ('state', '=', 'available'),
                    ]).write({
                        'state': 'skipped',
                    })

                    # and create a new one
                    update = self.create({
                        'build_id': build_id,
                        'build_number': build_number,
                        'product_code': product_code,
                        'short_description': short_description,
                        'full_description': full_description,
                        'details_url': product_update.get('details_url'),
                        'data': product_update.get('data', '').encode(),
                    })

                # save translations
                installed_langs = [r[0] for r in self.env['res.lang'].get_installed()]
                def _save_with_translations(field_name, value):
                    if value:
                        if isinstance(value, dict):
                            filtered_value = {k: v for k, v in value.items() if k in installed_langs}

                            if filtered_value:
                                if len(filtered_value) > 1:
                                    update.update_field_translations(field_name, filtered_value)
                                else:
                                    update[field_name] = list(filtered_value.values())[0]
                            else:
                                update[field_name] = list(value.values())[0]
                        else:
                            update[field_name] = value

                _save_with_translations('short_description', short_description)
                _save_with_translations('full_description', full_description)
