from typing import Dict, List

from odoo import api, models, fields

from ..const import (
    PRODUCT_CODE__DEFAULT,
    PARAM_NAME__INSTANCE_DATABASE_UUID,
    PARAM_NAME__INSTANCE_NAME,
    PARAM_NAME__INSTANCE_EMAIL,
    PARAM_NAME__INSTANCE_PHONE,
    PARAM_NAME__INSTANCE_REGISTERED,
    PARAM_NAME__INSTANCE_UPDATE_LAST_CHECK,
    PARAM_NAME__INSTANCE_UPDATE_LAST_DATE,
)


class ResConfigSettings(models.TransientModel):
    _inherit = 'res.config.settings'

    @api.model
    def _default_selferp_iap_registered(self):
        return self.env['ir.config_parameter'].sudo().get_param(PARAM_NAME__INSTANCE_REGISTERED)

    @api.model
    def _default_selferp_iap_product_available(self):
        return self._get_product_installed()

    @api.model
    def _default_selferp_iap_product_build_number(self):
        product_installed = self._get_product_installed()
        return product_installed and product_installed.get('build_number') or None

    @api.model
    def _default_selferp_iap_update_available(self):
        return self.env['iap.update'].sudo().search_count([('state', '=', 'available')])

    @api.model
    def _default_selferp_iap_update_build_number(self):
        product_update = self._get_product_update_available()
        return product_update and product_update.get('build_number') or None

    selferp_iap_client_dbuuid = fields.Char(
        config_parameter=PARAM_NAME__INSTANCE_DATABASE_UUID,
        readonly=True,
    )
    selferp_iap_client_name = fields.Char(
        config_parameter=PARAM_NAME__INSTANCE_NAME,
        readonly=True,
    )
    selferp_iap_client_email = fields.Char(
        config_parameter=PARAM_NAME__INSTANCE_EMAIL,
        readonly=True,
    )
    selferp_iap_client_phone = fields.Char(
        config_parameter=PARAM_NAME__INSTANCE_PHONE,
        readonly=True,
    )

    selferp_iap_registered = fields.Boolean(
        compute='_compute_selferp_iap_registered',
        readonly=True,
        default=lambda self: self._default_selferp_iap_registered(),
    )

    selferp_iap_update_last_check = fields.Datetime(
        config_parameter=PARAM_NAME__INSTANCE_UPDATE_LAST_CHECK,
        readonly=True,
    )
    selferp_iap_update_last_date = fields.Datetime(
        config_parameter=PARAM_NAME__INSTANCE_UPDATE_LAST_DATE,
        readonly=True,
    )
    selferp_iap_product_available = fields.Boolean(
        compute='_compute_selferp_iap_product_installed',
        string="Self-ERP Product Available",
        readonly=True,
        default=lambda self: self._default_selferp_iap_product_available(),
    )
    selferp_iap_product_build_number = fields.Char(
        compute='_compute_selferp_iap_product_installed',
        string="Self-ERP Product Build Number",
        default=lambda self: self._default_selferp_iap_product_build_number(),
    )
    selferp_iap_update_available = fields.Boolean(
        compute='_compute_selferp_iap_update_available',
        string="Self-ERP Update Available",
        readonly=True,
        default=lambda self: self._default_selferp_iap_update_available(),
    )
    selferp_iap_update_build_number = fields.Char(
        compute='_compute_selferp_iap_update_available',
        string="Self-ERP Update Build Number",
        default=lambda self: self._default_selferp_iap_update_build_number(),
    )

    #
    # Modules checkboxes
    #
    module_selferp_bundle_b2b = fields.Boolean()
    module_selferp_bundle_it = fields.Boolean()
    module_selferp_bundle_itdc = fields.Boolean()

    module_selferp_bundle_llc_vat = fields.Boolean()
    module_selferp_bundle_llc = fields.Boolean()
    module_selferp_bundle_pe_empl_vat = fields.Boolean()
    module_selferp_bundle_pe_empl = fields.Boolean()

    module_selferp_contract_settlement = fields.Boolean()
    module_selferp_cashflow_analytic = fields.Boolean()
    module_selferp_accountable_person = fields.Boolean()
    module_selferp_l10n_ua_bank_statement_import = fields.Boolean()
    module_selferp_l10n_ua_reconciliation_report = fields.Boolean()
    module_selferp_bank_so_po = fields.Boolean()

    module_selferp_l10n_ua_currency = fields.Boolean()
    module_selferp_currency_revaluation = fields.Boolean()
    module_selferp_partner_ledger_multi_currency = fields.Boolean()

    module_selferp_l10n_ua_vat = fields.Boolean()
    module_selferp_l10n_ua_vat_pos = fields.Boolean()
    module_selferp_l10n_ua_vat_export = fields.Boolean()
    module_selferp_l10n_ua_vat_cash = fields.Boolean()

    module_selferp_l10n_ua_salary = fields.Boolean()
    module_selferp_currency_salary = fields.Boolean()
    module_selferp_gig_salary = fields.Boolean()
    module_selferp_pe_salary = fields.Boolean()
    module_selferp_timesheet_salary = fields.Boolean()

    module_selferp_l10n_ua_fixed_asset = fields.Boolean()
    module_selferp_tax_fixed_assets = fields.Boolean()

    module_selferp_stock_inventory = fields.Boolean()
    module_selferp_l10n_ua_stock = fields.Boolean()

    module_selferp_l10n_ua_finance_report = fields.Boolean()

    module_selferp_l10n_ua_sale_print_form = fields.Boolean()
    module_selferp_l10n_ua_consignment_note = fields.Boolean()
    module_selferp_l10n_ua_cash_print_form = fields.Boolean()

    def _compute_selferp_iap_registered(self):
        selferp_iap_registered = self._default_selferp_iap_registered()
        for record in self:
            record.selferp_iap_registered = selferp_iap_registered

    def _compute_selferp_iap_product_installed(self):
        selferp_iap_product_installed = self._get_product_installed()

        for record in self:
            record.selferp_iap_product_available = selferp_iap_product_installed
            if selferp_iap_product_installed:
                record.selferp_iap_product_build_number = selferp_iap_product_installed.get('build_number')
            else:
                record.selferp_iap_product_build_number = None

    def _compute_selferp_iap_update_available(self):
        selferp_iap_product_update_available = self.env['iap.update'].sudo().search_read(
            domain=[
                ('product_code', '=', PRODUCT_CODE__DEFAULT),
                ('state', '=', 'available'),
            ],
            fields=['build_id', 'build_number'],
            order='id DESC',
            limit=1,
        )
        for record in self:
            record.selferp_iap_update_available = self._default_selferp_iap_update_available()
            if selferp_iap_product_update_available:
                selferp_iap_product_update_available = selferp_iap_product_update_available[0]
                record.selferp_iap_update_build_number = selferp_iap_product_update_available.get('build_number')
            else:
                record.selferp_iap_update_build_number = None

    #
    # Modules checkboxes
    #
    @api.onchange('module_selferp_bundle_b2b')
    def _onchange_module_selferp_bundle_b2b(self):
        if not self.env.context.get('onchange_first_call'):
            if self.module_selferp_bundle_b2b:
                self.module_selferp_accountable_person = True
                self.module_selferp_bank_so_po = True
                self.module_selferp_contract_settlement = True
                self.module_selferp_l10n_ua_cash_print_form = True
                self.module_selferp_l10n_ua_consignment_note = True
                self.module_selferp_l10n_ua_currency = True
                self.module_selferp_l10n_ua_finance_report = True
                self.module_selferp_l10n_ua_fixed_asset = True
                self.module_selferp_tax_fixed_assets = True
                self.module_selferp_l10n_ua_reconciliation_report = True
                self.module_selferp_l10n_ua_salary = True
                self.module_selferp_l10n_ua_sale_print_form = True
                self.module_selferp_l10n_ua_stock = True
                self.module_selferp_l10n_ua_vat = True
                self.module_selferp_l10n_ua_vat_cash = True
                self.module_selferp_l10n_ua_vat_pos = True
                self.module_selferp_l10n_ua_vat_export = True
            else:
                # do nothing for a bundle
                pass

    @api.onchange('module_selferp_bundle_it')
    def _onchange_module_selferp_bundle_it(self):
        if not self.env.context.get('onchange_first_call'):
            if self.module_selferp_bundle_it:
                self.module_selferp_accountable_person = True
                self.module_selferp_bank_so_po = True
                self.module_selferp_contract_settlement = True
                self.module_selferp_tax_fixed_assets = True
                self.module_selferp_currency_salary = True
                self.module_selferp_l10n_ua_cash_print_form = True
                self.module_selferp_l10n_ua_reconciliation_report = True
                self.module_selferp_l10n_ua_salary = True
                self.module_selferp_l10n_ua_stock = True
                self.module_selferp_pe_salary = True
                self.module_selferp_timesheet_salary = True
            else:
                # do nothing for a bundle
                pass

    @api.onchange('module_selferp_bundle_itdc')
    def _onchange_module_selferp_bundle_itdc(self):
        if not self.env.context.get('onchange_first_call'):
            if self.module_selferp_bundle_itdc:
                self.module_selferp_accountable_person = True
                self.module_selferp_bank_so_po = True
                self.module_selferp_contract_settlement = True
                self.module_selferp_tax_fixed_assets = True
                self.module_selferp_currency_salary = True
                self.module_selferp_l10n_ua_cash_print_form = True
                self.module_selferp_l10n_ua_reconciliation_report = True
                self.module_selferp_l10n_ua_salary = True
                self.module_selferp_l10n_ua_stock = True
                self.module_selferp_gig_salary = True
                self.module_selferp_pe_salary = True
                self.module_selferp_timesheet_salary = True
            else:
                # do nothing for a bundle
                pass

    @api.onchange('module_selferp_bundle_llc_vat')
    def _onchange_module_selferp_bundle_llc_vat(self):
        if not self.env.context.get('onchange_first_call'):
            if self.module_selferp_bundle_llc_vat:
                self.module_selferp_accountable_person = True
                self.module_selferp_bank_so_po = True
                self.module_selferp_contract_settlement = True
                self.module_selferp_l10n_ua_cash_print_form = True
                self.module_selferp_l10n_ua_consignment_note = True
                self.module_selferp_l10n_ua_currency = True
                self.module_selferp_l10n_ua_finance_report = True
                self.module_selferp_l10n_ua_fixed_asset = True
                self.module_selferp_l10n_ua_reconciliation_report = True
                self.module_selferp_l10n_ua_salary = True
                self.module_selferp_l10n_ua_sale_print_form = True
                self.module_selferp_l10n_ua_stock = True
                self.module_selferp_l10n_ua_vat = True
                self.module_selferp_l10n_ua_vat_cash = True
                self.module_selferp_l10n_ua_vat_pos = True
                self.module_selferp_l10n_ua_vat_export = True
            else:
                # do nothing for a bundle
                pass

    @api.onchange('module_selferp_bundle_llc')
    def _onchange_module_selferp_bundle_llc(self):
        if not self.env.context.get('onchange_first_call'):
            if self.module_selferp_bundle_llc:
                self.module_selferp_accountable_person = True
                self.module_selferp_bank_so_po = True
                self.module_selferp_contract_settlement = True
                self.module_selferp_l10n_ua_cash_print_form = True
                self.module_selferp_l10n_ua_consignment_note = True
                self.module_selferp_l10n_ua_currency = True
                self.module_selferp_l10n_ua_finance_report = True
                self.module_selferp_l10n_ua_fixed_asset = True
                self.module_selferp_l10n_ua_reconciliation_report = True
                self.module_selferp_l10n_ua_salary = True
                self.module_selferp_l10n_ua_sale_print_form = True
                self.module_selferp_l10n_ua_stock = True
            else:
                # do nothing for a bundle
                pass

    @api.onchange('module_selferp_bundle_pe_empl_vat')
    def _onchange_module_selferp_bundle_pe_empl_vat(self):
        if not self.env.context.get('onchange_first_call'):
            if self.module_selferp_bundle_pe_empl_vat:
                self.module_selferp_bank_so_po = True
                self.module_selferp_contract_settlement = True
                self.module_selferp_l10n_ua_consignment_note = True
                self.module_selferp_l10n_ua_reconciliation_report = True
                self.module_selferp_l10n_ua_salary = True
                self.module_selferp_l10n_ua_sale_print_form = True
                self.module_selferp_l10n_ua_vat = True
                self.module_selferp_l10n_ua_vat_cash = True
                self.module_selferp_l10n_ua_vat_pos = True
            else:
                # do nothing for a bundle
                pass

    @api.onchange('module_selferp_bundle_pe_empl')
    def _onchange_module_selferp_bundle_pe_empl(self):
        if not self.env.context.get('onchange_first_call'):
            if self.module_selferp_bundle_pe_empl:
                self.module_selferp_bank_so_po = True
                self.module_selferp_contract_settlement = True
                self.module_selferp_l10n_ua_consignment_note = True
                self.module_selferp_l10n_ua_reconciliation_report = True
                self.module_selferp_l10n_ua_salary = True
                self.module_selferp_l10n_ua_sale_print_form = True
            else:
                # do nothing for a bundle
                pass

    @api.onchange('module_selferp_contract_settlement')
    def _onchange_module_selferp_contract_settlement(self):
        if not self.env.context.get('onchange_first_call'):
            if self.module_selferp_contract_settlement:
                self.module_selferp_l10n_ua_sale_print_form = True
            else:
                self.module_selferp_bundle_b2b = False
                self.module_selferp_bundle_it = False
                self.module_selferp_bundle_itdc = False
                self.module_selferp_bundle_llc_vat = False
                self.module_selferp_bundle_llc = False
                self.module_selferp_bundle_pe_empl_vat = False
                self.module_selferp_bundle_pe_empl = False
                self.module_selferp_bank_so_po = False
                self.module_selferp_l10n_ua_reconciliation_report = False
                self.module_selferp_partner_ledger_multi_currency = False
                self.module_selferp_l10n_ua_vat = False

    @api.onchange('module_selferp_cashflow_analytic')
    def _onchange_module_selferp_cashflow_analytic(self):
        if not self.env.context.get('onchange_first_call'):
            # there are no any dependencies
            pass

    @api.onchange('module_selferp_accountable_person')
    def _onchange_module_selferp_accountable_person(self):
        if not self.env.context.get('onchange_first_call'):
            if self.module_selferp_accountable_person:
                # there are no any dependencies
                pass
            else:
                self.module_selferp_bundle_b2b = False
                self.module_selferp_bundle_it = False
                self.module_selferp_bundle_itdc = False
                self.module_selferp_bundle_llc_vat = False
                self.module_selferp_bundle_llc = False

    @api.onchange('module_selferp_l10n_ua_bank_statement_import')
    def _onchange_module_selferp_l10n_ua_bank_statement_import(self):
        if not self.env.context.get('onchange_first_call'):
            # there are no any dependencies
            pass

    @api.onchange('module_selferp_l10n_ua_reconciliation_report')
    def _onchange_module_selferp_l10n_ua_reconciliation_report(self):
        if not self.env.context.get('onchange_first_call'):
            if self.module_selferp_l10n_ua_reconciliation_report:
                self.module_selferp_contract_settlement = True
            else:
                self.module_selferp_bundle_b2b = False
                self.module_selferp_bundle_it = False
                self.module_selferp_bundle_itdc = False
                self.module_selferp_bundle_llc_vat = False
                self.module_selferp_bundle_llc = False
                self.module_selferp_bundle_pe_empl_vat = False
                self.module_selferp_bundle_pe_empl = False
                self.module_selferp_bank_so_po = False
                self.module_selferp_l10n_ua_vat = False

    @api.onchange('module_selferp_bank_so_po')
    def _onchange_module_selferp_bank_so_po(self):
        if not self.env.context.get('onchange_first_call'):
            if self.module_selferp_bank_so_po:
                self.module_selferp_contract_settlement = True
                self.module_selferp_l10n_ua_reconciliation_report = True
            else:
                self.module_selferp_bundle_b2b = False
                self.module_selferp_bundle_it = False
                self.module_selferp_bundle_itdc = False
                self.module_selferp_bundle_llc_vat = False
                self.module_selferp_bundle_llc = False
                self.module_selferp_bundle_pe_empl_vat = False
                self.module_selferp_bundle_pe_empl = False
                self.module_selferp_l10n_ua_vat = False

    @api.onchange('module_selferp_l10n_ua_currency')
    def _onchange_module_selferp_l10n_ua_currency(self):
        if not self.env.context.get('onchange_first_call'):
            if self.module_selferp_l10n_ua_currency:
                # there are no any dependencies
                pass
            else:
                self.module_selferp_bundle_b2b = False
                self.module_selferp_bundle_llc_vat = False
                self.module_selferp_bundle_llc = False
                self.module_selferp_l10n_ua_vat_export = False

    @api.onchange('module_selferp_currency_revaluation')
    def _onchange_module_selferp_currency_revaluation(self):
        if not self.env.context.get('onchange_first_call'):
            # there are no any dependencies
            pass

    @api.onchange('module_selferp_partner_ledger_multi_currency')
    def _onchange_module_selferp_partner_ledger_multi_currency(self):
        if not self.env.context.get('onchange_first_call'):
            if self.module_selferp_partner_ledger_multi_currency:
                self.module_selferp_contract_settlement = True
            else:
                # there are no any dependencies
                pass

    @api.onchange('module_selferp_l10n_ua_vat')
    def _onchange_module_selferp_l10n_ua_vat(self):
        if not self.env.context.get('onchange_first_call'):
            if self.module_selferp_l10n_ua_vat:
                self.module_selferp_bank_so_po = True
                self.module_selferp_contract_settlement = True
                self.module_selferp_l10n_ua_reconciliation_report = True
            else:
                self.module_selferp_bundle_b2b = False
                self.module_selferp_bundle_llc_vat = False
                self.module_selferp_bundle_pe_empl_vat = False
                self.module_selferp_l10n_ua_vat_cash = False
                self.module_selferp_l10n_ua_vat_pos = False
                self.module_selferp_l10n_ua_vat_export = False

    @api.onchange('module_selferp_l10n_ua_vat_cash')
    def _onchange_module_selferp_l10n_ua_vat_cash(self):
        if not self.env.context.get('onchange_first_call'):
            if self.module_selferp_l10n_ua_vat_cash:
                self.module_selferp_l10n_ua_vat = True
            else:
                self.module_selferp_bundle_b2b = False
                self.module_selferp_bundle_llc_vat = False
                self.module_selferp_bundle_pe_empl_vat = False

    @api.onchange('module_selferp_l10n_ua_vat_pos')
    def _onchange_module_selferp_l10n_ua_vat_pos(self):
        if not self.env.context.get('onchange_first_call'):
            if self.module_selferp_l10n_ua_vat_pos:
                self.module_selferp_l10n_ua_vat = True
            else:
                self.module_selferp_bundle_b2b = False
                self.module_selferp_bundle_llc_vat = False
                self.module_selferp_bundle_pe_empl_vat = False

    @api.onchange('module_selferp_l10n_ua_vat_export')
    def _onchange_module_selferp_l10n_ua_vat_export(self):
        if not self.env.context.get('onchange_first_call'):
            if self.module_selferp_l10n_ua_vat_export:
                self.module_selferp_l10n_ua_vat = True
                self.module_selferp_l10n_ua_currency = True
            else:
                self.module_selferp_bundle_b2b = False
                self.module_selferp_bundle_llc_vat = False

    @api.onchange('module_selferp_l10n_ua_salary')
    def _onchange_module_selferp_l10n_ua_salary(self):
        if not self.env.context.get('onchange_first_call'):
            if self.module_selferp_l10n_ua_salary:
                # there are no any dependencies
                pass
            else:
                self.module_selferp_bundle_b2b = False
                self.module_selferp_bundle_it = False
                self.module_selferp_bundle_itdc = False
                self.module_selferp_bundle_llc_vat = False
                self.module_selferp_bundle_llc = False
                self.module_selferp_bundle_pe_empl_vat = False
                self.module_selferp_bundle_pe_empl = False
                self.module_selferp_currency_salary = False
                self.module_selferp_gig_salary = False
                self.module_selferp_pe_salary = False
                self.module_selferp_timesheet_salary = False

    @api.onchange('module_selferp_currency_salary')
    def _onchange_module_selferp_currency_salary(self):
        if not self.env.context.get('onchange_first_call'):
            if self.module_selferp_currency_salary:
                self.module_selferp_l10n_ua_salary = True
            else:
                self.module_selferp_bundle_it = False
                self.module_selferp_currency_salary = False

    @api.onchange('module_selferp_gig_salary')
    def _onchange_module_selferp_gig_salary(self):
        if not self.env.context.get('onchange_first_call'):
            if self.module_selferp_gig_salary:
                self.module_selferp_l10n_ua_salary = True
            else:
                self.module_selferp_bundle_itdc = False

    @api.onchange('module_selferp_pe_salary')
    def _onchange_module_selferp_pe_salary(self):
        if not self.env.context.get('onchange_first_call'):
            if self.module_selferp_pe_salary:
                self.module_selferp_l10n_ua_salary = True
            else:
                self.module_selferp_bundle_it = False
                self.module_selferp_bundle_itdc = False

    @api.onchange('module_selferp_timesheet_salary')
    def _onchange_module_selferp_timesheet_salary(self):
        if not self.env.context.get('onchange_first_call'):
            if self.module_selferp_timesheet_salary:
                self.module_selferp_l10n_ua_salary = True
            else:
                self.module_selferp_bundle_it = False
                self.module_selferp_bundle_itdc = False

    @api.onchange('module_selferp_l10n_ua_fixed_asset')
    def _onchange_module_selferp_l10n_ua_fixed_asset(self):
        if not self.env.context.get('onchange_first_call'):
            if self.module_selferp_l10n_ua_fixed_asset:
                # there are no any dependencies
                pass
            else:
                self.module_selferp_bundle_b2b = False
                self.module_selferp_bundle_llc_vat = False
                self.module_selferp_bundle_llc = False

    @api.onchange('module_selferp_tax_fixed_assets')
    def _onchange_module_selferp_tax_fixed_assets(self):
        if not self.env.context.get('onchange_first_call'):
            if self.module_selferp_tax_fixed_assets:
                # there are no any dependencies
                pass
            else:
                self.module_selferp_bundle_b2b = False
                self.module_selferp_bundle_it = False
                self.module_selferp_bundle_itdc = False

    @api.onchange('module_selferp_stock_inventory')
    def _onchange_module_selferp_stock_inventory(self):
        if not self.env.context.get('onchange_first_call'):
            # there are no any dependencies
            pass

    @api.onchange('module_selferp_l10n_ua_stock')
    def _onchange_module_selferp_l10n_ua_stock(self):
        if not self.env.context.get('onchange_first_call'):
            if self.module_selferp_l10n_ua_stock:
                # there are no any dependencies
                pass
            else:
                self.module_selferp_bundle_b2b = False
                self.module_selferp_bundle_it = False
                self.module_selferp_bundle_itdc = False
                self.module_selferp_bundle_llc = False
                self.module_selferp_bundle_llc_vat = False

    @api.onchange('module_selferp_l10n_ua_finance_report')
    def _onchange_module_selferp_l10n_ua_finance_report(self):
        if not self.env.context.get('onchange_first_call'):
            if self.module_selferp_l10n_ua_finance_report:
                # there are no any dependencies
                pass
            else:
                self.module_selferp_bundle_b2b = False
                self.module_selferp_bundle_llc_vat = False
                self.module_selferp_bundle_llc = False

    @api.onchange('module_selferp_l10n_ua_sale_print_form')
    def _onchange_module_selferp_l10n_ua_sale_print_form(self):
        if not self.env.context.get('onchange_first_call'):
            if self.module_selferp_l10n_ua_sale_print_form:
                # there are no any dependencies
                pass
            else:
                self.module_selferp_bundle_b2b = False
                self.module_selferp_bundle_llc_vat = False
                self.module_selferp_bundle_llc = False
                self.module_selferp_bundle_pe_empl_vat = False
                self.module_selferp_bundle_pe_empl = False
                self.module_selferp_contract_settlement = False

    @api.onchange('module_selferp_l10n_ua_consignment_note')
    def _onchange_module_selferp_l10n_ua_consignment_note(self):
        if not self.env.context.get('onchange_first_call'):
            if self.module_selferp_l10n_ua_consignment_note:
                # there are no any dependencies
                pass
            else:
                self.module_selferp_bundle_b2b = False
                self.module_selferp_bundle_llc_vat = False
                self.module_selferp_bundle_llc = False
                self.module_selferp_bundle_pe_empl_vat = False
                self.module_selferp_bundle_pe_empl = False

    @api.onchange('module_selferp_l10n_ua_cash_print_form')
    def _onchange_module_selferp_l10n_ua_cash_print_form(self):
        if not self.env.context.get('onchange_first_call'):
            if self.module_selferp_l10n_ua_cash_print_form:
                # there are no any dependencies
                pass
            else:
                self.module_selferp_bundle_b2b = False
                self.module_selferp_bundle_it = False
                self.module_selferp_bundle_itdc = False
                self.module_selferp_bundle_llc_vat = False
                self.module_selferp_bundle_llc = False

    def onchange(self, values: Dict, field_names: List[str], fields_spec: Dict):
        # By base logic on load view, the onchange will be triggered for all fields.
        #
        # But in our case, we have the bundle's checkboxes which will set (check)
        # all the modules of the bundle.
        # As a result, if there is a module that is included in some already
        # installed bundle but not yet installed (for example, new one) -
        # this module will be checked even not installed on the first call of
        # onchange method for the bundle checkbox.
        #
        # So, add parameter about firs onchange call in context to analyze it in
        # onchange methods for modules.
        first_call = not field_names
        return super(ResConfigSettings, self.with_context(onchange_first_call=first_call)).onchange(values, field_names, fields_spec)

    def action_selferp_iap_setup(self):
        return self.env['iap.setup'].create_and_show()

    def action_selferp_iap_check_for_update(self):
        return self.env['iap.update'].sudo().iap_check_for_update()

    def action_selferp_iap_apply_update(self):
        return self.env['iap.update.confirm'].create_and_show()

    def _get_product_installed(self):
        product_installed = self.env['iap.update'].sudo().search_read(
            domain=[
                ('product_code', '=', PRODUCT_CODE__DEFAULT),
                ('state', '=', 'applied'),
            ],
            fields=['build_id', 'build_number'],
            order='id DESC',
            limit=1,
        )

        if product_installed:
            product_installed = product_installed[0]

        return product_installed

    def _get_product_update_available(self):
        product_update_available = self.env['iap.update'].sudo().search_read(
            domain=[
                ('product_code', '=', PRODUCT_CODE__DEFAULT),
                ('state', '=', 'available'),
            ],
            fields=['build_id', 'build_number'],
            order='id DESC',
            limit=1,
        )

        if product_update_available:
            product_update_available = product_update_available[0]

        return product_update_available
