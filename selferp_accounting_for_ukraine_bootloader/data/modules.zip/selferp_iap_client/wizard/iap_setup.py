from odoo import api, models, fields, _
from odoo.exceptions import UserError
from odoo.addons.mail.tools import mail_validation

from ..const import (
    PARAM_NAME__INSTANCE_NAME,
    PARAM_NAME__INSTANCE_EMAIL,
    PARAM_NAME__INSTANCE_PHONE,
    PARAM_NAME__INSTANCE_REGISTERED,
)


class IAPSetupWizard(models.TransientModel):
    _name = 'iap.setup'
    _description = "Self-ERP IAP Setup Wizard"

    name = fields.Char(
        string="Name",
    )
    email = fields.Char(
        string="Email",
    )
    phone = fields.Char(
        string="Phone",
    )

    email_validation_code = fields.Char(
        string="Email Validation Code",
    )

    state = fields.Selection(
        selection=[
            ('register', "Registration"),
            ('validate_email', "Validate Email"),
            ('done', "Done"),
        ],
        required=True,
    )

    agree = fields.Boolean(
        string="I agree",
        default=False,
    )
    agree_label = fields.Html(
        compute='_compute_agree_label',
    )

    def _compute_agree_label(self):
        agree_label = '%s <a href="https://www.self-erp.com/%sprivacy-policy" target="_blank">%s</a>' % (
            _("Confirm that you consent to the processing of personal data and accept the terms of the"),
            (self.env.context.get('lang') or self.env.user.lang or 'en_US').startswith('en') and 'en/' or '',
            _("Privacy Policy"),
        )
        for record in self:
            record.agree_label = agree_label

    @api.model
    def create_and_show(self):
        IrConfigParameter = self.env['ir.config_parameter'].sudo()

        if not IrConfigParameter.get_param(PARAM_NAME__INSTANCE_REGISTERED):
            # open registration wizard
            wizard = self.create({
                'state': 'register',
                'name': IrConfigParameter.get_param(PARAM_NAME__INSTANCE_NAME) or self.env.company.name,
                'email': IrConfigParameter.get_param(PARAM_NAME__INSTANCE_EMAIL) or self.env.company.email or self.env.user.email,
                'phone': IrConfigParameter.get_param(PARAM_NAME__INSTANCE_PHONE) or self.env.company.phone or self.env.company.phone or self.env.user.phone or self.env.user.mobile,
            })
            return wizard._show()

        else:
            # if there is any record in the update info table,
            # it means registration already done
            self.env['iap.update'].iap_apply_update()

        # close wizard
        return self._close_wizard()

    def action_next(self):
        self.ensure_one()

        IrConfigParameter = self.env['ir.config_parameter'].sudo()

        if self.state == 'register':
            if not mail_validation.mail_validate(self.email):
                raise UserError(_("Invalid email"))

            # remember instance info
            IrConfigParameter.set_param(PARAM_NAME__INSTANCE_NAME, self.name)
            IrConfigParameter.set_param(PARAM_NAME__INSTANCE_EMAIL, self.email)
            IrConfigParameter.set_param(PARAM_NAME__INSTANCE_PHONE, self.phone)

            # call server
            self.env['iap.update'].iap_register()

            # switch state
            self.write({
                'state': 'validate_email',
                'email_validation_code': None,
            })

            # and show the wizard again
            return self._show()

        elif self.state == 'validate_email':
            # complete registration
            self.env['iap.update'].iap_complete_registration(self.email_validation_code.strip())

            # switch state
            self.state = 'done'

        # close the wizard
        return self._close_wizard()

    def _show(self):
        self.ensure_one()
        return {
            'name': _("Self-ERP Registration") if self.state == 'register' else _("Self-ERP Initial Setup"),
            'type': 'ir.actions.act_window',
            'res_model': self._name,
            'res_id': self.id,
            'view_mode': 'form',
            'target': 'new',
        }

    def _close_wizard(self):
        if self:
            # remove this wizard instance
            self.unlink()
        return {
            'type': 'ir.actions.client',
            'tag': 'reload',
            'effect': {
                'type': 'rainbow_man',
                'message': _("Congratulations! Your instance registered and initial setup already done!"),
            },
        }
