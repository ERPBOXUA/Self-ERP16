from odoo import api, models, fields, _

from ..const import (
    PRODUCTS,
    PRODUCT_CODE__LOADER,
    PRODUCT_CODE__DEFAULT,
)


class IAPUpdateConfirm(models.TransientModel):
    _name = 'iap.update.confirm'
    _description = "Self-ERP IAP update confirmation wizard"

    update_loader_exists = fields.Boolean(
        string="Update Loader Exists",
        default=False,
        readonly=True,
    )
    update_loader_title = fields.Char(
        string="Update Loader Title",
        readonly=True,
    )
    update_loader_description = fields.Html(
        string="Update Loader Description",
        readonly=True,
    )

    update_ua_acc_exists = fields.Boolean(
        string="Update Oblik UA Exists",
        default=False,
        readonly=True,
    )
    update_ua_acc_title = fields.Char(
        string="Update Oblik UA Title",
        readonly=True,
    )
    update_ua_acc_description = fields.Html(
        string="Update Oblik UA Description",
        readonly=True,
    )
    update_ua_acc_url = fields.Html(
        string="Update Oblik UA URL",
        readonly=True,
    )

    agree = fields.Boolean(
        string="I agree",
        default=False,
    )

    @api.model
    def create_and_show(self):
        IAPUpdate = self.env['iap.update'].sudo()
        if not IAPUpdate.search_count([('state', '=', 'available')]):
            return {
                'type': 'ir.actions.client',
                'tag': 'reload',
                'effect': {
                    'type': 'rainbow_man',
                    'message': _("Congratulations! Your instance is up to date!"),
                },
            }

        values = {}

        # get available updates
        for product_code in PRODUCTS:
            update = IAPUpdate.search(
                domain=[
                    ('product_code', '=', product_code),
                    ('state', '=', 'available'),
                ],
                order='id DESC',
                limit=1,
            )

            if update:
                description = (update.full_description or '').strip()
                if description:
                    description = f'<div style="width: 100%; max-height: 200px; padding: 8px; border-radius: 5px; overflow: auto; background-color: lightgray; font-size: 0.8em; font-family: var(--font-monospace); white-space: pre-line;">{description}</div>'

                values.update({
                    f'update_{product_code}_exists': True,
                    f'update_{product_code}_title': update.short_description,
                    f'update_{product_code}_description': description,
                })

                if product_code != PRODUCT_CODE__LOADER:
                    details_url = ''
                    if update.details_url:
                        details_url = update.details_url
                    elif product_code == PRODUCT_CODE__DEFAULT:
                        details_url = 'https://www.self-erp.com/knowledge/article/1370'

                    if details_url:
                        values.update({
                            f'update_{product_code}_url': '<a href="%s" target="_blank">%s</a>' % (
                                details_url,
                                _("View the full product changelog"),
                            ),
                        })

        # create and show wizard
        if values:
            wizard = self.create(values)

            # and show it
            return {
                'type': 'ir.actions.act_window',
                'name': _("Confirm Update Applying"),
                'res_model': 'iap.update.confirm',
                'res_id': wizard.id,
                'view_mode': 'form',
                'target': 'new',
            }

    def action_confirm(self):
        self.ensure_one()

        if not self.agree:
            return

        # apply update
        self.env['iap.update'].sudo().iap_apply_update()

        # refresh view (actually this action will never be called)
        return {
            'type': 'ir.actions.client',
            'tag': 'reload',
        }
